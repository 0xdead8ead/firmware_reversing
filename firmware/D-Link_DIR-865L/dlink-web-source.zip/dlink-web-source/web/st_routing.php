HTTP/1.1 200 OK

<?


/*necessary and basic definition */
$TEMP_MYNAME    = "st_routing";
$TEMP_MYGROUP   = "status";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>