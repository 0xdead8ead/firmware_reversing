<?
include "/htdocs/web/tools_admin.php";
?>
