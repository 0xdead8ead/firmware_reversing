HTTP/1.1 200 OK

<?
/*necessary and basic definition */
$TEMP_MYNAME    = "dlna_refresh";
$TEMP_MYGROUP   = "";
$TEMP_STYLE		= "progress";
include "/htdocs/webinc/templates.php";
?>
