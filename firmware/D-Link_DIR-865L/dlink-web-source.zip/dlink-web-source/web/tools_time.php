HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "tools_time";
$TEMP_MYGROUP   = "tools";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
