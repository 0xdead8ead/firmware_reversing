HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "adv_wlan_wifitest";
$TEMP_MYGROUP   = "advanced";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
