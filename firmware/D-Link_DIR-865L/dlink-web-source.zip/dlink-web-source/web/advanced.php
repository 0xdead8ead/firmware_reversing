<?
if(query("/device/layout")=="router")
{
	include "/htdocs/web/adv_vsvr.php";
}
else
{
	include "/htdocs/web/noadvance.php";
}
?>
