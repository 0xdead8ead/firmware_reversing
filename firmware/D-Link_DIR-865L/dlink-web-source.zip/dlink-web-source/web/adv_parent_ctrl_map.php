HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "adv_parent_ctrl_map";
$TEMP_MYGROUP   = "";
$TEMP_STYLE		= "simple";
include "/htdocs/webinc/templates.php";
?>
