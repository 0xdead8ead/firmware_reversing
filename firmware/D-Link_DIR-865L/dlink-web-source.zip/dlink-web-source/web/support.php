<?
include "/htdocs/web/spt_menu.php";
?>
