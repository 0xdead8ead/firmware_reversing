HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "bsc_wan";
$TEMP_MYGROUP   = "basic";
$TEMP_STYLE     = "complex";
include "/htdocs/webinc/templates.php";
?>

