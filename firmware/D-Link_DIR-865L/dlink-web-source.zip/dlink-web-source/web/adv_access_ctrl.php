HTTP/1.1 200 OK

<?
include "/htdocs/phplib/xnode.php";
include "/htdocs/phplib/inet.php";
/* The variables are used in js and body both, so define them here. */

/* necessary and basic definition */
$TEMP_MYNAME	= "adv_access_ctrl";
$TEMP_MYGROUP	= "advanced";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
