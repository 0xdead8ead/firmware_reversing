HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "noadvance";
$TEMP_MYGROUP   = "advance";
$TEMP_STYLE		= "complex";
include "/htdocs/webinc/templates.php";
?>
