<?
include "/htdocs/web/bsc_internet.php";
?>
