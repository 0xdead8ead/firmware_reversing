HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "st_routingv6";
$TEMP_MYGROUP   = "status";
$TEMP_STYLE	= "complex";
include "/htdocs/webinc/templates.php";
?>
