HTTP/1.1 200 OK

<?
$TEMP_MYNAME    = "info";
$TEMP_MYGROUP   = "";
$TEMP_STYLE		= "simple";
include "/htdocs/webinc/templates.php";
?> 