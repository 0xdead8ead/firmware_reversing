<? include "/htdocs/phplib/setcfg/DDNS4.WAN-1.php"; ?>
